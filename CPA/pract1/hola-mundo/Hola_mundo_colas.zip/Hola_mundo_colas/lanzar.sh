#!/bin/sh
#SBATCH --nodes=1
#SBATCH --time=5:00
#SBATCH --partition=cpa
OMP_NUM_THREADS=32 ./Hola_Mundo_OMP 
