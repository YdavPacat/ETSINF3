 void pasar_a_ID_NOP (void);
 void pasar_a_EX_NOP (void);
 void pasar_a_MEM_NOP (void);
 void pasar_a_WB_NOP (void);
 void pasar_a_FP_LS_NOP (void);
 void pasar_a_FP_A_NOP (void);
 void pasar_a_FP_M_NOP (void);
 void pasar_a_FP_C_NOP (void);
 void pasar_a_FP_LS2_NOP (void);
 void pasar_a_FP_A2_NOP (void);
 void pasar_a_FP_M2_NOP (void);
 void pasar_a_FP_C2_NOP (void);
 void pasar_a_ID_WB_NOP (void);
 void pasar_a_FP_LS_WB_NOP (void);
 boolean hay_fuente1 ( 
	instruccion_t inst
	 );
 boolean hay_fuente2 ( 
	instruccion_t inst
	 );
 boolean hay_destino ( 
	instruccion_t inst
	 );
 boolean hay_fuente1_ID (void);
 boolean hay_fuente2_ID (void);
 boolean hay_fuente1_EX (void);
 boolean hay_fuente2_EX (void);
 boolean hay_destino_EX (void);
 boolean hay_destino_MEM (void);
 boolean hay_destino_WB (void);
 boolean hay_fuente1_FP_ID (void);
 boolean hay_fuente2_FP_ID (void);
 boolean hay_destino_FP_WB (void);
 boolean hay_fuente1_A1 (void);
 boolean hay_fuente1_M1 (void);
 boolean hay_fuente1_C1 (void);
 boolean hay_fuente2_A1 (void);
 boolean hay_fuente2_M1 (void);
 boolean hay_fuente2_C1 (void);
 boolean hay_fuente1_LS1 (void);
 boolean hay_fuente2_LS1 (void);
 boolean hay_fuente2_LS2 (void);
