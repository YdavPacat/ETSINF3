
/* Funciones exportables */

#ifndef CPROTO
#include "mips_syscall_api.h"
#endif
